# Example

```js
npm install
node node_modules/scripted-browser --run=search-a-website
```
